package com.example;

public class Onibus extends Veiculo{

    public static final int tanque = 200;
    private int quantidadeEixos;

    public Onibus(String marca, String modelo, int ano, int capacidadePassageiros, String combustivel, int quantidadeEixos) {
        super(marca, modelo, ano, capacidadePassageiros, combustivel);
        this.quantidadeEixos = quantidadeEixos;
        if (quantidadeEixos < 6 || quantidadeEixos > 8) {
            throw new IllegalArgumentException("O número de eixos deve ser entre 6 e 8.");
        }
    }

    @Override
    public double calcularAutonomia() {
        //tanque de 200L consumo 5Km/L
        return tanque*5;
    }


    public int getQuantidadeEixos() {
        return quantidadeEixos;
    }
}
