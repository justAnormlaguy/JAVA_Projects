package com.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner ler = new Scanner(System.in);
        int x;


        Carro carro = new Carro("Toyota", "Corolla", 2022, 5, "Gasolina", "Sedan");
        CarroEletrico carroEletrico = new CarroEletrico("Tesla", "Model S", 2024, 5, "--", "Sedan");
        Caminhao caminhao = new Caminhao("Volvo", "FH", 2021, 2, "Diesel", 38);
        CaminhaoRefrigerado caminhaoRefrigerado = new CaminhaoRefrigerado("Scania", "P360", 2023, 2, "Diesel", 38);

        //o onibus1 vai gerar um argument exception, para o codigo funcionar deve comentar esta linha, junto com o resto da escolha. Isto é apenas para testes
        //Onibus onibus1 = new Onibus("Mercedes-Benz", "O500", 2020, 50, "Diesel", 10);
        Onibus onibus2 = new Onibus("Volvo", "B12M", 2022, 60, "Diesel", 6);


        do {
            System.out.println("Por favor digite o número do veículo para mais detalhes!");
            System.out.println("1. Toyota Corolla");
            System.out.println("2. Tesla Model S");
            System.out.println("3. Volvo FH");
            System.out.println("4. Scania P360");
            System.out.println("5. Mercedes-Benz O500");
            System.out.println("6. Volvo B12M");
            System.out.println("0. Sair");
            x = ler.nextInt();

            switch (x) {
                case 1:
                    System.out.println("Detalhes do Carro:");
                    carro.exibirDetalhes();
                    System.out.println("Capacidade do Tanque: " + Carro.tanque + " litros");
                    System.out.println("Tipo do Carro: " + carro.getTipoCarro());
                    System.out.println("Autonomia do Carro: " + carro.calcularAutonomia() + " km\n");
                    break;
                case 2:
                    System.out.println("Detalhes do Carro Elétrico:");
                    carroEletrico.exibirDetalhes();
                    System.out.println("Capacidade da Bateria: " + CarroEletrico.bateriaKWh + " kWh");
                    System.out.println("Tipo do Carro: " + carro.getTipoCarro());
                    System.out.println("Autonomia do Carro Elétrico: " + carroEletrico.calcularAutonomia() + " km\n");
                    break;
                case 3:
                    System.out.println("Detalhes do Caminhão:");
                    caminhao.exibirDetalhes();
                    System.out.println("Capacidade do Tanque: " + Caminhao.tanque + " litros");
                    System.out.println("Capacidade de Carga: " + caminhao.getCapacidadeCarga() + " toneladas");
                    System.out.println("Autonomia do Caminhão: " + caminhao.calcularAutonomia() + " km\n");
                    break;
                case 4:
                    System.out.println("Detalhes do Caminhão Refrigerado:");
                    caminhaoRefrigerado.exibirDetalhes();
                    System.out.println("Capacidade do Tanque: " + CaminhaoRefrigerado.tanque + " litros");
                    System.out.println("Temperatura Miníma: " + CaminhaoRefrigerado.temperaturaMinima + " Graus");
                    System.out.println("Capacidade de Carga: " + caminhaoRefrigerado.getCapacidadeCarga() + " toneladas");
                    System.out.println("Autonomia do Caminhão Refrigerado: " + caminhaoRefrigerado.calcularAutonomia() + " km\n");
                    break;
                case 5:
                    System.out.println("Veiculo indisponivel");
                    //System.out.println("Detalhes do Ônibus:");
                    //onibus1.exibirDetalhes();
                    //System.out.println("Capacidade do Tanque: " + Onibus.tanque + " litros");
                    //System.out.println("Quantidade de Eixos: " + onibus1.getQuantidadeEixos());
                    //System.out.println("Autonomia do Ônibus: " + onibus1.calcularAutonomia() + " km\n");
                    break;
                case 6:
                    System.out.println("Detalhes do Ônibus:");
                    onibus2.exibirDetalhes();
                    System.out.println("Capacidade do Tanque: " + Onibus.tanque + " litros");
                    System.out.println("Quantidade de Eixos: " + onibus2.getQuantidadeEixos());
                    System.out.println("Autonomia do Ônibus: " + onibus2.calcularAutonomia() + " km\n");
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (x != 0);

        ler.close();
    }
}
