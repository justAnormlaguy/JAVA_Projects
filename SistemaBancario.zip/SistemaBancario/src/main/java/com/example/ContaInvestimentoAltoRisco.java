package com.example;

public class ContaInvestimentoAltoRisco extends  ContaInvestimento{

    private static final double taxa_saque = 0.05;
    private static final double valor_minimo = 10000.00;

    public ContaInvestimentoAltoRisco(int numeroConta, String titular, double saldo) {
        super(numeroConta, titular, saldo);
    }

    @Override
    public double sacar(double valor) {

        double taxa = valor * taxa_saque;
        double valorTotal = valor + taxa;
        double saldoAposSaque = getSaldo() - valorTotal;

        if (saldoAposSaque >= valor_minimo) {
            System.out.println("Saque de R$ " + valor + " realizado com sucesso.");
            System.out.println("Taxa de retirada aplicada: R$ " + taxa);
            depositar(-valorTotal);
        } else {
            System.out.println("Saldo insuficiente. O saldo não pode ficar abaixo de R$ " + valor_minimo + " após o saque.");
        }
        return super.sacar(valor);
    }
}
