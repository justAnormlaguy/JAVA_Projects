package com.example;

public abstract class ContaBancaria {

    private int numeroConta;
    private String titular;
    public double saldo;

    public ContaBancaria(int numeroConta, String titular, double saldo) {
        this.numeroConta = numeroConta;
        this.titular = titular;
        this.saldo = saldo;
    }

    public double depositar(double valor){
        return saldo + valor;
    }

    public abstract double sacar(double valor);

    public void exibirInformacoes(){
        System.out.println("\nNumero da conta: \n" + numeroConta +
                            "\nTitular: \n" + titular +
                            "\nSaldo: " + saldo);
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public String getTitular() {
        return titular;
    }

    public double getSaldo() {
        return saldo;
    }
}
