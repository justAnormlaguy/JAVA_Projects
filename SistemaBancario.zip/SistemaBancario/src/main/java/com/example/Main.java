package com.example;

public class Main {
    public static void main(String[] args) {


        ContaCorrente contaCOrrente1 = new ContaCorrente(1234, "João Silva", 1000);
        System.out.println("\n=== Conta Corrente ===");
        contaCOrrente1.exibirInformacoes();
        contaCOrrente1.sacar(1100);
        contaCOrrente1.sacar(200);

        ContaInvestimento contaInvest = new ContaInvestimento(5678, "Maria Oliveira", 2000);
        System.out.println("\n=== Conta Investimento ===");
        contaInvest.exibirInformacoes();
        contaInvest.sacar(500);

        ContaInvestimentoAltoRisco contaInvesAltoRisco = new ContaInvestimentoAltoRisco(9101, "Carlos Souza", 50000);
        System.out.println("\n=== Conta Investimento Alto Risco ===");
        contaInvesAltoRisco.exibirInformacoes();
        contaInvesAltoRisco.sacar(20000);
        contaInvesAltoRisco.sacar(40000);

        ContaPoupanca contaPoup = new ContaPoupanca(1122, "Ana Costa", 1500);
        System.out.println("\n=== Conta Poupança ===");
        contaPoup.exibirInformacoes();
        contaPoup.sacar(2000);
        contaPoup.sacar(1000);

        ContaSalario contaSala = new ContaSalario(3344, "Lucas Lima", 800, 0);
        System.out.println("\n=== Conta Salário ===");
        contaSala.exibirInformacoes();
        contaSala.sacar(100);
        contaSala.sacar(100);
    }
}
